﻿开发环境管理器 (DevBox)
========================================

Windows 多版本开发环境管理器：图形化下载、安装、切换
Java / Node.js / Python / PHP / Maven / MySQL / Redis，
并为 MySQL / Redis 提供多实例服务化管理。

快速开始：
  1. 启动 DevBox.exe（首次会请求管理员权限）
  2. 左侧选择环境 → 「下载新版本」下载 → 「已安装版本」设为当前
  3. 新开命令行窗口，java/node/mvn 等命令即指向所选版本

数据目录：D:\环境管理\data（不占用 C 盘）

更多文档（与本文件同目录）：
  - README.md      中文说明
  - README.en.md   English version
  - LICENSE        开源许可

开发者：子柒
许可证：MIT License
版本：1.0.0
